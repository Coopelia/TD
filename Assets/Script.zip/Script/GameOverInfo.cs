﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOverInfo : MonoBehaviour
{
    public void OnClickedOk()
    {
        this.gameObject.SetActive(false);
        UnityEngine.SceneManagement.SceneManager.LoadScene("Start");
    }
}
