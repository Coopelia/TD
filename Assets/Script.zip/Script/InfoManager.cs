﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InfoManager : MonoBehaviour
{
    public Canvas tipsInfo;
    public Canvas seletedTurretInfo;
    public Canvas upgradeTurretInfo;
    public Canvas bussinessmanInfo;
    public Canvas equipmentInfo;
    public Canvas gameOverInfo;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
